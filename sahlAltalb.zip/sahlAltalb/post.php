<?php
   require_once 'check.php';
?>


   <div class="page-title">
      <h2>Page name</h2>
   </div>
   <main class="section">
      <div class="container main-container">
         <div class="message">
            <div class="title">
               <i class="fas fa-file fa-3x"></i>
               <h2 class="title">Post full title without cut any thig</h2>
            </div>
            <!-- <p dir="rtl">بعد تسجيل الدخول الى الموقع يتم الانتقال الى الصفحة الرئيسية حيث يتم عرض جزء من قائمة الصفحات في الموقع بحسب التفضيلات للمستخدم , تحتوي هذه الصفحة أيضا على قائمة جانبية تحتوي على روابط للمفضلة و الاشتراكات و الاعدادات و الصفحات الاساسية مثل سياسة الخصوصية و اتصل بنا </p> -->
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
               Minus necessitatibus perspiciatis quas minima voluptatem magnam totam voluptatum ad soluta, 
               sit corporis commodi itaque obcaecati error inventore rerum atque distinctio accusamus nostrum quos vel fugit! Labore nesciunt,
               in consequuntur officia sint pariatur suscipit beatae a facilis neque perferendis odio, 
               magnam numquam error magni ipsam velit nihil! Quo labore, et, 
               quisquam, debitis odio assumenda voluptas vero modi deleniti enim temporibus sint officiis eaque itaque reprehenderit doloribus omnis quis nemo quod! Nostrum doloremque repellendus, in eius eum velit! Officiis magnam nobis praesentium omnis enim. Adipisci qui enim expedita labore eaque aperiam reiciendis ratione quos neque officia laboriosam dicta inventore molestias vitae, earum quo odio optio quia nobis error consectetur, culpa consequuntur. Dolore quis dolor voluptate ab minus explicabo, animi dolorem illum excepturi, expedita fugit ex quam eaque? Magni, illo. Neque repellat maxime rem doloremque molestiae odio qui dolorem fuga harum, voluptas autem. Labore minus adipisci, amet eum, recusandae odit beatae ea fugit culpa consectetur blanditiis officiis provident voluptatem. Dicta, excepturi maiores corporis autem reiciendis dolore veniam adipisci. Beatae, quidem necessitatibus quia suscipit qui nostrum magnam laboriosam esse nulla blanditiis, aperiam officiis, consequatur velit quibusdam deleniti accusantium facere.
               Accusantium dolorum commodi asperiores sapiente aperiam?
            </p>
            <div class="share button-list">
               <div class="item">
                  <i class="fas fa-share"></i>
                  <span>share</span>
               </div>
               <div class="item">
                  <i class="fa-solid fa-thumbs-down"></i>
                  <span>dis like</span>
               </div>
               <div class="item">
                  <i class="fas fa-thumbs-up"></i>
                  <span>like</span>
               </div>
               <div class="item">
                  <i class="fas fa-heart"></i>
                  <span>favorite</span>
               </div>
               <div class="item">
                  <i class="fas fa-download"></i>
                  <span>download</span>
               </div>
            </div>
         </div>
      </div>
      
   </main>


<?php
   require_once PATH . 'static/footer.php';
?>