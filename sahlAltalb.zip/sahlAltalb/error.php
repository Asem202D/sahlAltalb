<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="fontawsom/css/all.min.css">
   <link rel="stylesheet" href="css/main.css">
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>ERROR</title>
</head>
<body>
   <main class="error-main">
      <div class="container main-container error-container">
         <i class="fas fa-message"></i>
         <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam cupiditate, praesentium in beatae sit ipsum aut voluptatum assumenda illo soluta non et aliquam? Hic laborum et possimus reprehenderit ab est.</p>
         <a href="index.php"><button class="button">Home Page</button></a>
      </div>
   </main>
</body>
</html>