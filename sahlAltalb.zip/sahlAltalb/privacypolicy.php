<?php
   require_once 'check.php';
?>


   <main class="section">
      <div class="container center-container main-container">
         <div class="text">
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Enim quia in suscipit nihil inventore totam! Dignissimos est officiis ut cumque fuga deleniti. Asperiores culpa magnam harum molestiae molestias accusamus illum sit ipsum in voluptatibus mollitia dolorem quaerat tempore quod illo fugiat saepe eveniet ab laborum nihil non, totam obcaecati sapiente quae. Asperiores alias atque in veritatis expedita perferendis! Accusantium cumque, temporibus assumenda laboriosam, saepe inventore dignissimos in ratione magni non architecto nihil cupiditate illo vel rerum dolore nobis. Eius labore mollitia voluptatum dolores esse id nulla? Quibusdam saepe facere veniam maxime dolorem necessitatibus neque praesentium cupiditate incidunt aliquam? Reprehenderit, unde?</p>
         </div>
      </div>
   </main>

   

<?php
   require_once PATH . 'static/footer.php';
?>