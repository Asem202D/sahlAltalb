<footer>
      <div class="container">
         <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nesciunt ipsam nam itaque nemo autem officia nihil dolore dolor? Eos, quidem eveniet autem pariatur debitis a iste necessitatibus quod animi in.</p>
         <div class="social">
            <div class="item">
               <i class="fab fa-github"></i>
               <span>github</span>
            </div>
            <div class="item">
               <i class="fab fa-instagram"></i>
               <span>instagram</span>
            </div>
            <div class="item">
               <i class="fab fa-telegram"></i>
               <span>telegram</span>
            </div>
            <div class="item">
               <i class="fab fa-google"></i>
               <span>google</span>
            </div>
         </div>
      </div>
   </footer>
</body>
</html>